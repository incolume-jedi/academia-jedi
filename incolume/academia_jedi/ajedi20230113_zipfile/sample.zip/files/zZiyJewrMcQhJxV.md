# CHANGELOG


All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

This file was automatically generated for [incolumepy.utils](https://gitlab.com/development-incolume/incolumepy.utils/-/tree/2.6.0a1)

---
## [v0.1.0]	 &#8212; 	2022-12-01:
  - Added: record
## [v0.1.0-alpha.1]	 &#8212; 	2022-12-01:
  - Deprecated: ass
## [v0.1.0-alpha.0]	 &#8212; 	2022-12-01:
  - Changed: dev fake
## [v0.0.1]	 &#8212; 	2022-12-01:
  - Added: initial
## [v0.0.1-rc.21]	 &#8212; 	2022-12-01:
  - Deprecated: as
## [v0.0.1-rc.12]	 &#8212; 	2022-12-01:
  - Removed: as
## [v0.0.1-rc.11]	 &#8212; 	2022-12-01:
  - Changed: as
## [v0.0.1-rc.3]	 &#8212; 	2022-12-01:
  - Added: as
## [v0.0.1-rc.2]	 &#8212; 	2022-12-01:
  - Fixed: as
## [v0.0.1-rc.1]	 &#8212; 	2022-12-01:
  - as
## [v0.0.1-rc.0]	 &#8212; 	2022-12-01:
  - Fixed: as
## [v0.0.1-alpha.0]	 &#8212; 	2022-12-01:
  - Security: as
## [v0.0.1-beta.0]	 &#8212; 	2022-12-01:
  - Added: a
## [v0.0.1-dev.0]	 &#8212; 	2022-12-01:
  - Changed: asd
---

[v0.1.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1...v0.1.0
[v0.1.0-alpha.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.1.0...v0.1.0-alpha.0
[v0.1.0-alpha.1]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.1.0-alpha.0...v0.1.0-alpha.1
[v0.0.1-rc.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.1.0-alpha.1...v0.0.1-rc.0
[v0.0.1-alpha.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-rc.0...v0.0.1-alpha.0
[v0.0.1-beta.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-alpha.0...v0.0.1-beta.0
[v0.0.1-dev.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-beta.0...v0.0.1-dev.0
[v0.0.1-rc.1]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-dev.0...v0.0.1-rc.1
[v0.0.1-rc.2]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-rc.1...v0.0.1-rc.2
[v0.0.1-rc.11]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-rc.2...v0.0.1-rc.11
[v0.0.1-rc.3]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-rc.11...v0.0.1-rc.3
[v0.0.1-rc.12]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-rc.3...v0.0.1-rc.12
[v0.0.1-rc.21]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/v0.0.1-rc.12...v0.0.1-rc.21
