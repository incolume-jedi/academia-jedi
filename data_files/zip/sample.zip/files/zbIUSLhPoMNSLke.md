# CHANGELOG


All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

This file was automatically generated for [incolumepy.utils](https://gitlab.com/development-incolume/incolumepy.utils/-/tree/2.6.0a2)

---
## [0.0.1]	 &#8212; 	2022-12-01:
  - Fake record
## [0.1.0]	 &#8212; 	2022-12-01:
  - system
## [0.1.1-alpha.0]	 &#8212; 	2022-12-01:
  - Fake record
## [0.1.1-rc.0]	 &#8212; 	2022-12-01:
  - Fake record
## [0.1.1-rc.1]	 &#8212; 	2022-12-01:
  - Fake record
## [0.1.1]	 &#8212; 	2022-12-01:
  - Fake record
## [0.2.0]	 &#8212; 	2022-12-01:
  - Fake record
---

[0.1.1]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/0.1.0...0.1.1
[0.1.1-alpha.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/0.1.1...0.1.1-alpha.0
[0.1.1-rc.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/0.1.1-alpha.0...0.1.1-rc.0
[0.1.1-rc.1]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/0.1.1-rc.0...0.1.1-rc.1
[0.2.0]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/0.1.1-rc.1...0.2.0
[0.0.1]: https://gitlab.com/development-incolume/incolumepy.utils/-/compare/0.2.0...0.0.1
